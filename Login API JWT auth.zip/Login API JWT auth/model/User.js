const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true,
        min: 6,
        max: 100
    },
    email: {
        type: String,
        required: true,
        min: 6,
        max: 250
    },
    password: {
        type: String,
        required: true,
        min: 6,
        max: 100
    },
    phone: {
        type: Number,
        required: true,

    }
});

module.exports = mongoose.model('User', userSchema);